// src/constants/permissions.ts
export const PERMISSIONS = {
  READ: 'read',
  WRITE: 'write',
  DELETE: 'delete'
}
