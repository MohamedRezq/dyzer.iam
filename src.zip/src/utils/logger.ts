// src/utils/logger.ts
function log(message: string) {
  console.log(message)
}

export { log }
