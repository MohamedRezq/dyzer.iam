// src/config/database.ts
const databaseConfig = {
  url: process.env.DATABASE_URL
}

export default databaseConfig
