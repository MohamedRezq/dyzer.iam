// src/config/index.ts
import databaseConfig from './database'
import authConfig from './auth'

export { databaseConfig, authConfig }
